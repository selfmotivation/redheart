const form = document.querySelector('.form');
const formField = document.querySelector('.form__field');
const testButton = document.querySelector('.main__test-btn');


function showForm() {
    form.style.display = 'flex';
    fadeIn();

}

function fadeIn() {
    setTimeout(() => {
        form.style.opacity = '100%';
    }, 50);
    setTimeout(() => {
        formField.style.opacity = '100%';
    }, 200);
}

testButton.addEventListener('click', () => {
    // form.style.display = 'flex';
    // form.classList.add('opa');
    showForm();
});

form.addEventListener('click', e => {
    // console.log(e.target);
    if (e.target === form || e.target.getAttribute('data-close') == '') {
        closeForm();
    }
});

function closeForm() {
    
    formField.style.opacity = '0';
    fadeOut();
}

function fadeOut() {
    setTimeout(() => {
        form.style.opacity = '0';
    }, 0);
    setTimeout(() => {
        form.style.display = 'none';
    }, 200);
}

const formCurrentStep = document.querySelector('.form__select_step-1');
const options = formCurrentStep.querySelectorAll('.form__select-option');
const statusBar = document.querySelector('.status-bar');
const currentStatus = statusBar.querySelectorAll('.status-bar__current-status_active');
    
console.log(options);

// for (let i = 0; i < options.length; i++) {
//     options[i].addEventListener('click', fillStatusBar);
// }
options.forEach(option => {
        option.addEventListener('click', fillStatusBar);
    
});
function fillStatusBar(event) {
    // console.log(this);
    console.log(this.tagName);
    currentStatus[0].style.width = '100%';
}

